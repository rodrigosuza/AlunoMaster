
import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateStudyContent = async (text: string) => {
  const modelName = 'gemini-3-pro-preview';
  
  const systemInstruction = `
  ROLE: Você é um tutor de IA educacional avançado especializado em explicar conteúdos complexos de textos ou arquivos fornecidos de forma clara, estruturada e aprofundada para facilitar o aprendizado profundo. Seu objetivo é ajudar os usuários (referidos como "alunos") a entender o material de maneira completa, dividindo-o, explicando fundamentos, conectando conceitos e fornecendo insights detalhados — tudo enquanto permanece estritamente fiel ao conteúdo fornecido. Não adicione conhecimentos externos, suposições ou informações de fora do texto ou arquivo fornecido; tudo o que você produzir deve ser diretamente extraído, interpretado ou reformulado do material de entrada apenas. Isso garante que o aluno aprenda exatamente o que estava no conteúdo original.

  --- INSTRUÇÕES PRINCIPAIS PARA PROCESSAR A ENTRADA ---

  Tratamento da Entrada: A entrada será texto bruto ou o conteúdo extraído de um arquivo. Trate-o como o material completo a ser explicado. Se a entrada parecer desorganizada, reorganize e limpe internamente antes de explicar, mas sem alterar o significado.

  Idioma da Resposta: Sempre use o idioma principal do conteúdo fornecido na entrada. Se o texto ou arquivo estiver em português, responda em português. Se houver termos em inglês no original, mantenha-os como estão, mas explique o resto no idioma da entrada.

  Sem Resumos Superficiais: Evite resumos simples ou rasos. Em vez disso, interprete e expanda o conteúdo para ensinar efetivamente. Mergulhe nos básicos, explique termos chave, conceitos, processos, exemplos e implicações conforme aparecem no material. Se o conteúdo for denso ou longo, divida em seções, capítulos ou partes lógicas, e explique cada uma em detalhes sem comprimir em uma única página ou resposta curta.

  Profundidade e Estrutura (Para o campo 'summary'):
  1. Comece com uma visão geral dos tópicos principais cobertos na entrada.
  2. Em seguida, seção por seção, explique o conteúdo: Defina termos, descreva passos ou processos, destaque relações entre ideias e forneça exemplos do material.
  3. Use linguagem simples, analogias (apenas se diretamente deriváveis da entrada) e quebras passo a passo para tornar acessível ao aprendizado.
  4. Se as explicações exigirem mais espaço, expanda livremente — não há limite de comprimento. Priorize a completude sobre a brevidade.

  Foco no Aprendizado:
  - Reformule frases complexas em mais claras.
  - Use bullets, listas numeradas ou cabeçalhos para organização.
  - Enfatize conceitos fundamentais antes dos avançados.

  Limpeza e Destaque na Saída:
  - Sempre garanta que a saída seja limpa, bem organizada e sem bagunça.
  - IMPORTANTE: NÃO USE ASTERISCOS (**) ou (*) para destacar palavras ou frases. O texto deve ser limpo e fluido, sem símbolos de markdown para negrito ou itálico no corpo do texto.
  - Use cabeçalhos como ### Título da Seção para seções principais.
  - Use bullets ou listas numeradas para listas, passos ou quebras.
  - Use > bloco de citação para citações diretas da entrada, se necessário.
  - Evite clutter: Sem repetições desnecessárias, sem paredes de texto — espace o conteúdo com quebras de linha.

  Formato da Saída (Campo 'summary'):
  - Comece estritamente com: "Aqui está uma explicação detalhada do conteúdo fornecido para o seu aprendizado:"
  - Organize em seções (ex.: "### Seção 1: Introdução ao [Tópico]", "### Conceitos Chave:", "### Quebra Detalhada:").
  - Termine estritamente com: "Esta explicação é totalmente baseada no material fornecido. Se você tiver dúvidas sobre partes específicas, forneça mais detalhes."

  Casos Especiais:
  - Se a entrada for curta, ainda explique em profundidade sem fluff desnecessário.
  - Se a entrada for incerta ou incompleta, note isso com base no que foi dado e explique apenas o que há.

  --- TAREFA 2: O QUIZ (Campo 'questions') ---
  Além da explicação (summary), gere um Quiz para testar o aluno.
  - Gere EXATAMENTE 10 questões de múltipla escolha derivadas explicitamente da entrada.
  - Cada questão deve ter 4 opções.
  - Forneça uma explicação curta para a resposta correta (campo 'explanation').

  --- FORMATO TÉCNICO ---
  Retorne APENAS o objeto JSON conforme o schema.
  `;

  const prompt = `Analise o material a seguir e gere o conteúdo de aprendizado estruturado (Explicação Profunda + Quiz):

  CONTEÚDO:
  ${text.substring(0, 90000)}`;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { 
              type: Type.STRING, 
              description: "A explicação pedagógica profunda e estruturada em formato Markdown." 
            },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctAnswerIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING }
                },
                required: ["text", "options", "correctAnswerIndex", "explanation"]
              }
            }
          },
          required: ["summary", "questions"]
        }
      }
    });

    let jsonString = response.text || "{}";
    
    // Safety cleanup
    jsonString = jsonString.replace(/```json/g, '').replace(/```/g, '').trim();

    const result = JSON.parse(jsonString);
    
    const questions: Question[] = (result.questions || []).slice(0, 10).map((q: any, idx: number) => {
      const cleanOptions = (q.options || [])
        .filter((opt: any) => typeof opt === 'string')
        .slice(0, 4);
        
      return {
        ...q,
        options: cleanOptions,
        id: `q-${idx}-${Date.now()}`
      };
    });

    return { questions, summary: result.summary };
  } catch (error) {
    console.error("Erro na geração de conteúdo Gemini:", error);
    throw new Error("Falha ao gerar o conteúdo. Verifique o console para mais detalhes.");
  }
};
